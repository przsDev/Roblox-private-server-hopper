Thanks for downloading!

Here is some simple instructions on how to use this tool.

1. Launch the tool (roblox_serverlist_hopper.exe)

This tool uses Roblox private server links and hops through them at your command.
There is 2 ways to provide this tool Roblox private server links.

1. Via making a txt file with private server links on each line
2. Putting them in a google doc, then putting said doc link into the hopper (needs to be public)

Once this is done you can press Join server and you can begin your hopping! 

There is more to be added to this tool such as better invalid link handling and UI.

But then again, thanks for downloading.
And as always, the code is open source and free to read and change!